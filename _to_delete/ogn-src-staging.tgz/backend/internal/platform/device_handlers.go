package platform

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base32"
	"encoding/hex"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/gerege-systems/open-gerege-nexus/backend/internal/platform/audit"
	"github.com/gerege-systems/open-gerege-nexus/backend/internal/platform/auth"
	"github.com/gerege-systems/open-gerege-nexus/backend/internal/platform/httpx"
	"github.com/gerege-systems/open-gerege-nexus/backend/internal/platform/tenant"
	"github.com/jackc/pgx/v5"
)

const enrollmentTTL = 10 * time.Minute

type deviceContextKey struct{}
type deviceClaims struct{ ID, TenantID, Name, Platform, FormFactor string }

func opaqueSecret(bytes int) (string, error) {
	value := make([]byte, bytes)
	if _, err := rand.Read(value); err != nil {
		return "", err
	}
	return hex.EncodeToString(value), nil
}

func enrollmentCode() (string, error) {
	value := make([]byte, 10)
	if _, err := rand.Read(value); err != nil {
		return "", err
	}
	raw := base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(value)
	return raw[:4] + "-" + raw[4:8] + "-" + raw[8:12] + "-" + raw[12:], nil
}

func secretHash(value string) string {
	sum := sha256.Sum256([]byte(strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(value), "-", ""))))
	return hex.EncodeToString(sum[:])
}

func caseSensitiveSecretHash(value string) string {
	sum := sha256.Sum256([]byte(strings.TrimSpace(value)))
	return hex.EncodeToString(sum[:])
}

func validDeviceKind(platform, formFactor string) bool {
	platforms := map[string]bool{"windows": true, "android": true, "macos": true, "ios": true}
	factors := map[string]bool{"desktop": true, "mobile": true, "tablet": true, "kiosk": true, "pos": true}
	return platforms[platform] && factors[formFactor]
}

func (s *Server) handleCreateEnrollmentCode(w http.ResponseWriter, r *http.Request) {
	claims, err := auth.UserFromContext(r.Context())
	if err != nil {
		httpx.Error(w, http.StatusUnauthorized, "unauthorized")
		return
	}
	code, err := enrollmentCode()
	if err != nil {
		httpx.Error(w, 500, "failed to create enrollment code")
		return
	}
	expires := time.Now().Add(enrollmentTTL)
	_, err = s.db.Exec(r.Context(), `INSERT INTO device_enrollment_codes(tenant_id,code_hash,created_by,expires_at) VALUES($1,$2,$3,$4)`, claims.TenantID, secretHash(code), claims.UserID, expires)
	if err != nil {
		httpx.Error(w, 500, "failed to persist enrollment code")
		return
	}
	audit.Record(r.Context(), claims.TenantID, claims.UserID, "device.enrollment_code_created", "device", nil)
	httpx.JSON(w, http.StatusCreated, map[string]any{"code": code, "expires_at": expires})
}

func (s *Server) handleEnrollDevice(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Code       string `json:"code"`
		Name       string `json:"name"`
		Platform   string `json:"platform"`
		FormFactor string `json:"form_factor"`
		Site       string `json:"site"`
		AppVersion string `json:"app_version"`
		OSVersion  string `json:"os_version"`
	}
	if decodeLimitedJSON(r, &req, 16<<10) != nil {
		httpx.Error(w, 400, "invalid enrollment request")
		return
	}
	req.Name, req.Platform, req.FormFactor = strings.TrimSpace(req.Name), strings.ToLower(strings.TrimSpace(req.Platform)), strings.ToLower(strings.TrimSpace(req.FormFactor))
	if req.Name == "" || !validDeviceKind(req.Platform, req.FormFactor) || len(strings.TrimSpace(req.Code)) < 12 {
		httpx.Error(w, 400, "invalid device identity")
		return
	}
	token, err := opaqueSecret(32)
	if err != nil {
		httpx.Error(w, 500, "failed to create device token")
		return
	}
	tx, err := s.db.Begin(r.Context())
	if err != nil {
		httpx.Error(w, 503, "enrollment unavailable")
		return
	}
	defer func() { _ = tx.Rollback(r.Context()) }()
	var codeID, tenantID string
	err = tx.QueryRow(r.Context(), `SELECT id::text,tenant_id::text FROM resolve_device_enrollment($1)`, secretHash(req.Code)).Scan(&codeID, &tenantID)
	if errors.Is(err, pgx.ErrNoRows) {
		httpx.Error(w, 401, "enrollment code is invalid or expired")
		return
	}
	if err != nil {
		httpx.Error(w, 503, "enrollment unavailable")
		return
	}
	if _, err = tx.Exec(r.Context(), `SELECT set_config('app.current_tenant',$1,true)`, tenantID); err != nil {
		httpx.Error(w, 503, "enrollment unavailable")
		return
	}
	var deviceID string
	err = tx.QueryRow(r.Context(), `INSERT INTO devices(tenant_id,name,platform,form_factor,site,token_hash,app_version,os_version,last_seen_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,NOW()) RETURNING id::text`, tenantID, req.Name, req.Platform, req.FormFactor, strings.TrimSpace(req.Site), secretHash(token), strings.TrimSpace(req.AppVersion), strings.TrimSpace(req.OSVersion)).Scan(&deviceID)
	if err == nil {
		_, err = tx.Exec(r.Context(), `UPDATE device_enrollment_codes SET used_at=NOW() WHERE id=$1 AND used_at IS NULL`, codeID)
	}
	if err != nil || tx.Commit(r.Context()) != nil {
		httpx.Error(w, 503, "enrollment could not be completed")
		return
	}
	audit.Record(r.Context(), tenantID, "device:"+deviceID, "device.enrolled", "device", map[string]any{"platform": req.Platform, "form_factor": req.FormFactor})
	httpx.JSON(w, http.StatusCreated, map[string]any{"device_id": deviceID, "device_token": token, "tenant_id": tenantID})
}

func deviceTokenFromRequest(r *http.Request) string {
	const prefix = "Device "
	value := strings.TrimSpace(r.Header.Get("Authorization"))
	if strings.HasPrefix(value, prefix) {
		return strings.TrimSpace(strings.TrimPrefix(value, prefix))
	}
	if cookie, err := r.Cookie("device_token"); err == nil {
		return strings.TrimSpace(cookie.Value)
	}
	return ""
}

func (s *Server) deviceMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token := deviceTokenFromRequest(r)
		if token == "" {
			httpx.Error(w, 401, "missing device token")
			return
		}
		var claims deviceClaims
		err := s.db.QueryRow(r.Context(), `SELECT id::text,tenant_id::text,name,platform,form_factor FROM authenticate_device($1)`, secretHash(token)).Scan(&claims.ID, &claims.TenantID, &claims.Name, &claims.Platform, &claims.FormFactor)
		if errors.Is(err, pgx.ErrNoRows) {
			httpx.Error(w, 401, "invalid device token")
			return
		}
		if err != nil {
			httpx.Error(w, 503, "device authentication unavailable")
			return
		}
		ctx := context.WithValue(r.Context(), deviceContextKey{}, claims)
		ctx = tenant.WithTenantID(ctx, claims.TenantID)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func (s *Server) handleDeviceMe(w http.ResponseWriter, r *http.Request) {
	claims, ok := r.Context().Value(deviceContextKey{}).(deviceClaims)
	if !ok {
		httpx.Error(w, 401, "unauthorized device")
		return
	}
	httpx.JSON(w, 200, map[string]any{"id": claims.ID, "tenant_id": claims.TenantID, "name": claims.Name, "platform": claims.Platform, "form_factor": claims.FormFactor, "status": "ACTIVE"})
}

func (s *Server) handleRotateDeviceToken(w http.ResponseWriter, r *http.Request) {
	claims, ok := r.Context().Value(deviceContextKey{}).(deviceClaims)
	if !ok {
		httpx.Error(w, 401, "unauthorized device")
		return
	}
	token, err := opaqueSecret(32)
	if err != nil {
		httpx.Error(w, 500, "failed to rotate device token")
		return
	}
	result, err := s.db.Exec(r.Context(), `UPDATE devices SET token_hash=$3,updated_at=NOW() WHERE id=$1 AND tenant_id=$2 AND status='ACTIVE'`, claims.ID, claims.TenantID, secretHash(token))
	if err != nil || result.RowsAffected() != 1 {
		httpx.Error(w, 503, "device token rotation failed")
		return
	}
	audit.Record(r.Context(), claims.TenantID, "device:"+claims.ID, "device.token_rotated", "device", nil)
	httpx.JSON(w, 200, map[string]string{"device_token": token})
}

func (s *Server) handleUpdateDeviceStatus(w http.ResponseWriter, r *http.Request) {
	tenantID, ok := tenant.Require(w, r)
	if !ok {
		return
	}
	var req struct {
		ID     string `json:"id"`
		Status string `json:"status"`
	}
	if decodeLimitedJSON(r, &req, 8<<10) != nil {
		httpx.Error(w, 400, "invalid device status")
		return
	}
	req.Status = strings.ToUpper(strings.TrimSpace(req.Status))
	if req.Status != "ACTIVE" && req.Status != "DISABLED" && req.Status != "RETIRED" {
		httpx.Error(w, 400, "invalid device status")
		return
	}
	result, err := s.db.Exec(r.Context(), `UPDATE devices SET status=$3,updated_at=NOW() WHERE id=$1 AND tenant_id=$2`, req.ID, tenantID, req.Status)
	if err != nil || result.RowsAffected() != 1 {
		httpx.Error(w, 404, "device not found")
		return
	}
	httpx.JSON(w, 200, map[string]string{"status": req.Status})
}

func (s *Server) handleListDevices(w http.ResponseWriter, r *http.Request) {
	tenantID, ok := tenant.Require(w, r)
	if !ok {
		return
	}
	rows, err := s.db.Query(r.Context(), `SELECT id::text,name,platform,form_factor,site,status,app_version,os_version,last_seen_at,enrolled_at FROM devices WHERE tenant_id=$1 ORDER BY name`, tenantID)
	if err != nil {
		httpx.Error(w, 500, "failed to load devices")
		return
	}
	defer rows.Close()
	devices := make([]map[string]any, 0)
	for rows.Next() {
		var id, name, platform, factor, site, status, appVersion, osVersion string
		var lastSeen *time.Time
		var enrolled time.Time
		if rows.Scan(&id, &name, &platform, &factor, &site, &status, &appVersion, &osVersion, &lastSeen, &enrolled) != nil {
			httpx.Error(w, 500, "failed to read devices")
			return
		}
		devices = append(devices, map[string]any{"id": id, "name": name, "platform": platform, "form_factor": factor, "site": site, "status": status, "app_version": appVersion, "os_version": osVersion, "last_seen_at": lastSeen, "enrolled_at": enrolled})
	}
	if rows.Err() != nil {
		httpx.Error(w, 500, "failed to read devices")
		return
	}
	httpx.JSON(w, 200, map[string]any{"devices": devices})
}
