# Баримт бичгийн төв — Documentation Hub

> Энэ бүх баримт нь вэб хэлбэрээр
> **[gerege-systems.github.io/open-gerege-nexus](https://gerege-systems.github.io/open-gerege-nexus/)**
> хаяг дээр нийтлэгддэг. Сайт нь энэ хавтасны Markdown файлуудаас
> угсрагддаг тул эх сурвалж нь энд хэвээр байна —
> [`docs/site/`](site/) хавтсыг үзнэ үү.

Энэ хавтас нь **Gerege Nexus**-ын бүх баримт бичиг болон орчуулгыг
агуулна. Үндсэн хэл нь монгол; орчуулгууд нь файлын нэрийн `_AR`, `_ZH`, `_EN`,
`_FR`, `_RU`, `_ES` дагаварт хадгалагдана.

**Хэлний бодлого: монгол хэл + НҮБ-ын албан ёсны 6 хэл** (араб, хятад, англи,
франц, орос, испани) — нийт 7 хэл. Монгол хэл эх сурвалж, бусад нь орчуулга.
Шинэ хэл нэмэхийн өмнө энэ бодлогыг өөрчлөх шаардлагатай: жагсаалт нь дур
зоргоор биш, олон улсын байгууллагуудын хэрэглэдэг жишигт тулгуурласан.

This directory holds every Gerege Nexus document and translation. Mongolian is
the source language. **The language policy is Mongolian plus the six official
languages of the United Nations** (Arabic, Chinese, English, French, Russian,
Spanish) — seven in total.

<p>
  <a href="../README.md"><img src="assets/icons/flag-mn.png" width="18" height="18" alt=""> Монгол</a>
  &nbsp;·&nbsp;
  <a href="README_AR.md"><img src="assets/icons/flag-ar.png" width="18" height="18" alt=""> العربية</a>
  &nbsp;·&nbsp;
  <a href="README_ZH.md"><img src="assets/icons/flag-zh.png" width="18" height="18" alt=""> 中文</a>
  &nbsp;·&nbsp;
  <a href="README_EN.md"><img src="assets/icons/flag-en.png" width="18" height="18" alt=""> English</a>
  &nbsp;·&nbsp;
  <a href="README_FR.md"><img src="assets/icons/flag-fr.png" width="18" height="18" alt=""> Français</a>
  &nbsp;·&nbsp;
  <a href="README_RU.md"><img src="assets/icons/flag-ru.png" width="18" height="18" alt=""> Русский</a>
  &nbsp;·&nbsp;
  <a href="README_ES.md"><img src="assets/icons/flag-es.png" width="18" height="18" alt=""> Español</a>
</p>

---

## Танилцуулга — Overview

| Хэл | Файл |
| --- | --- |
| Монгол (эх сурвалж) | [`../README.md`](../README.md) |
| العربية | [`README_AR.md`](README_AR.md) |
| 中文 | [`README_ZH.md`](README_ZH.md) |
| English | [`README_EN.md`](README_EN.md) |
| Français | [`README_FR.md`](README_FR.md) |
| Русский | [`README_RU.md`](README_RU.md) |
| Español | [`README_ES.md`](README_ES.md) |

## Техникийн баримт — Technical documentation

| Баримт | Хэл | Тайлбар |
| --- | --- | --- |
| [`ARCHITECTURE_SPECIFICATION.md`](ARCHITECTURE_SPECIFICATION.md) | MN | Платформын давхаргууд, өгөгдлийн загвар, архитектурын шийдвэрүүд |
| [`ARCHITECTURE_SPECIFICATION_EN.md`](ARCHITECTURE_SPECIFICATION_EN.md) | EN | Architecture specification |
| [`SSO_FEDERATION.md`](SSO_FEDERATION.md) | MN | Нэг суулгацыг нөгөөгийн SSO клиент болгох: env, урсгал, гарах зам |
| [`ECOSYSTEM_GIT_STRATEGY.md`](ECOSYSTEM_GIT_STRATEGY.md) | MN | Зуун платформ нэг цөм дээр: юу цөмд үлдэж, юу distribution болох, хилийг хэрхэн тестээр барих |
| [`adr/0001-domain-first.md`](adr/0001-domain-first.md) | MN | Домэйн эхэнд: аппын дүрэм платформоо мэдэхгүй — хэрэгжилт, хоёр хойшлуулалт, дөрвөн дүрэм |
| [`adr/0002-one-signing-rail.md`](adr/0002-one-signing-rail.md) | MN | Гарын үсгийн зам нэг (`eidmongolia`), ба «гарын үсэг» гэдэг үг хоёр зүйлийг нэрлэж байсан нь |
| [`adr/0003-a-document-carries-what-is-signed.md`](adr/0003-a-document-carries-what-is-signed.md) | MN | Баримт файлаа авч явна; гурван хэлбэр — pades, detached, approval |
| [`SHELL_CONTRACT.md`](SHELL_CONTRACT.md) | MN | Native бүрхүүл ба web ажлын мужийн `window.GeregeShell` гэрээ |
| [`NATIVE_LOGIN_SPEC.md`](NATIVE_LOGIN_SPEC.md) | MN | Swift, C#, Kotlin клиентүүдийн нэвтрэлтийн зан төлөв |
| [`NATIVE_SETTINGS_SPEC.md`](NATIVE_SETTINGS_SPEC.md) | MN | Бүрхүүл, төхөөрөмж, peripheral, fleet тохиргоо |
| [`MODULE_AUTHORING_GUIDE.md`](MODULE_AUTHORING_GUIDE.md) | EN | Шинэ апп модуль хөгжүүлэх алхам алхмаар заавар |
| [`RELEASING.md`](RELEASING.md) | MN | `pkg/nexus`-ийн semver амлалт, түүнийг хамгаалдаг тест, tag гаргах журам |
| [`GOV_SERVICES_WORKFLOW.md`](GOV_SERVICES_WORKFLOW.md) | EN | Тохируулж болох төрийн үйлчилгээний урсгал, шилжүүлэлт, баталгаажуулалт |
| [`DOCUMENTS_SIGNING.md`](DOCUMENTS_SIGNING.md) | EN | Цахим баримтын гарын үсэг ба батламжийн урсгал |
| [`APPSTORE_OPERATIONS.md`](APPSTORE_OPERATIONS.md) | EN | Апп сторын каталог нийтлэх, хувилбар шилжүүлэх ажиллагаа |
| [`REPORTS.md`](REPORTS.md) | MN | Тайлангийн хөдөлгүүр: шинэ тайлан нэмэх, хамгаалалт, товлосон илгээлт |
| [`REPORT_SHARING.md`](REPORT_SHARING.md) | MN | Тенант дамнасан тайлан: grant, counterparty хүрээ, хоёр талын audit |
| [`URTUU.md`](URTUU.md) | MN | «Өртөө» — платформ хоорондын даалгаврын суваг: тохиргоо, холбоос байгуулах, runbook |
| [`RING_STANDARD.md`](RING_STANDARD.md) | MN | Үйлчилгээний процессын бүртгэлийн формат — ring.dgov.mn-д санал болгож буй гэрээ |
| [`MONITORING.md`](MONITORING.md) | MN | Ажиглалтын стек: асаах, Grafana, лог хайх, шинэ хэмжүүр нэмэх |
| [`RUNBOOKS.md`](RUNBOOKS.md) | MN | Дохио бүрд: юу болсон, юу шалгах, яаж засах, хэзээ өргөжүүлэх |
| [`CONTROL_PLANE.md`](CONTROL_PLANE.md) | MN | Операторын консол: босгох, эрх, анхны оператор үүсгэх, аюулгүй байдлын дүрмүүд |
| [`MONITORING_AND_REPORTING_PROPOSAL.md`](MONITORING_AND_REPORTING_PROPOSAL.md) | MN | Ажиглалт ба тайлангийн давхаргын дизайны санал |
| [`URTUU_PROPOSAL.md`](URTUU_PROPOSAL.md) | MN | «Өртөө» сувгийн дизайны санал ба үе шатууд |
| [`CONTROL_PLANE_PLAN.md`](CONTROL_PLANE_PLAN.md) | MN | Операторын консолын дизайн ба үе шатуудын төлөвлөгөө |
| [`PEER_PROPOSAL.md`](PEER_PROPOSAL.md) | MN | «Хөрш» — Nexus биш системийг Өртөөний бүрэн эрхт талд оруулах санал |
| [`APPSTORE_SEPARATION_PLAN.md`](APPSTORE_SEPARATION_PLAN.md) | MN | App Store-ыг appstore.gerege.mn дээр салгаж байршуулах төлөвлөгөө |
| [`APPSTORE_PHASE2_PLAN.md`](APPSTORE_PHASE2_PLAN.md) | MN | «Шастир» ба платформ нэгдлийн 2-р үе шатын төлөвлөгөө |
| [`DOCUMENTS_WORKLOG.md`](DOCUMENTS_WORKLOG.md) | MN | Баримт ба цахим гарын үсгийн ажлын төлөв — юу хийгдсэн, юу үлдсэн |
| [`TRANSLATION_GUIDE.md`](TRANSLATION_GUIDE.md) | MN | Долоон хэлний толь бичиг, орчуулга нэмэх урсгал |

## Хэрэгжүүлэлтийн prompt-ууд — Implementation prompts

Хийгдсэн ажлыг хэрхэн даалгасныг үлдээсэн бичвэрүүд. Тэдгээр нь түүх:
prompt-ын төлөвлөгөө ба эцэст нь хэрэгжсэн зүйл заримдаа зөрдөг, тэр
зөрүү нь ADR-д тэмдэглэгддэг.

| Баримт | Хэл | Тайлбар |
| --- | --- | --- |
| [`MODULE_RENAME_PROMPT.md`](MODULE_RENAME_PROMPT.md) | MN | Цөмийн модулиудын нэршлийн засвар (салгалтын 0-р алхам) |
| [`MONITORING_AND_REPORTING_IMPLEMENTATION_PROMPT.md`](MONITORING_AND_REPORTING_IMPLEMENTATION_PROMPT.md) | MN | Мониторинг ба тайлангийн системийг хэрэгжүүлэх prompt |
| [`DOMAIN_FIRST_PROMPT.md`](DOMAIN_FIRST_PROMPT.md) | MN | Домэйн давхаргыг салгах prompt — үр дүн нь [`adr/0001-domain-first.md`](adr/0001-domain-first.md) |

## Төслийн журам — Project governance

| Баримт | Хэл | Тайлбар |
| --- | --- | --- |
| [`../CONTRIBUTING.md`](../CONTRIBUTING.md) | MN | Хувь нэмэр оруулах журам |
| [`CONTRIBUTING_EN.md`](CONTRIBUTING_EN.md) | EN | Contribution guide |
| [`../CODE_OF_CONDUCT.md`](../CODE_OF_CONDUCT.md) | MN | Ёс зүйн дүрэм |
| [`CODE_OF_CONDUCT_EN.md`](CODE_OF_CONDUCT_EN.md) | EN | Code of conduct |
| [`../SECURITY.md`](../SECURITY.md) | MN | Аюулгүй байдлын бодлого |
| [`SECURITY_EN.md`](SECURITY_EN.md) | EN | Security policy |
| [`../CHANGELOG.md`](../CHANGELOG.md) | EN | Өөрчлөлтийн түүх |

---

## Орчуулга нэмэх — Adding a translation

1. Эх баримтыг хуулж, файлын нэрэнд ISO 639-1 хэлний код бүхий дагавар нэмнэ:
   `README_JA.md`, `CONTRIBUTING_JA.md` гэх мэт.
2. Баримтын эхэнд, оршил догол мөрийн дараа, badge-үүдийн өмнө хэлний
   сонголтын мөрийг байрлуулна. Туг бүрийн зураг
   [`assets/icons/`](assets/icons/)-д хадгалагдана.
3. Бүх хэлний хувилбар дээрх сонголтын мөрийг шинэ хэлээр нөхнө — сонголт нь
   хэлүүдийн хооронд тэгш хэмтэй байх ёстой.
4. Энэ индекс файлын хүснэгтэд шинэ мөр нэмнэ.

Хэлний сонголтын мөрийн загвар (`docs/` доторх файлд):

```html
<p>
  <a href="../README.md"><img src="assets/icons/flag-mn.png" width="18" height="18" alt=""> Монгол</a>
  &nbsp;·&nbsp;
  <a href="README_EN.md"><img src="assets/icons/flag-en.png" width="18" height="18" alt=""> English</a>
</p>
```

Идэвхтэй байгаа хэлийг холбоосгүй, `<b>` тэгээр тодруулна.

---

## Дүрсний эх сурвалж — Icon source

Тугны дүрсийг [Flaticon](https://www.flaticon.com/)-оос авч репод хадгалсан.
Дэлгэрэнгүйг [`assets/icons/ATTRIBUTION.md`](assets/icons/ATTRIBUTION.md)-ээс
үзнэ үү. Баримт бичигт emoji дүрс ашиглахгүй — бүх дүрс нь Flaticon-ы дүрсийн
сангаас авсан зураг байна.
